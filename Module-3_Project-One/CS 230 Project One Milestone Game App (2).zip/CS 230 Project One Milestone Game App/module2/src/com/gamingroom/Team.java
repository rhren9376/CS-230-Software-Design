package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a team.
 * 
 * @author Richard Hren
 * richard.hren@snhu.edu
 */
public class Team extends Entity {

	/*
	 * List of players associated with the team
	 */
	private List<Player> players = new ArrayList<Player>();

	/*
	 * Constructor with identifier and name
	 */
	public Team(long id, String name) {
		super(id, name);
	}

	/**
	 * Adds a player if name does not already exist.
	 * 
	 * @param name unique player name
	 * @return new or existing player
	 */
	public Player addPlayer(String name) {

		Player player = null;

		Iterator<Player> playerIterator = players.iterator();

		while (playerIterator.hasNext()) {

			Player existingPlayer = playerIterator.next();

			if (existingPlayer.getName().equalsIgnoreCase(name)) {
				player = existingPlayer;
				break;
			}
		}

		if (player == null) {
			player = new Player(GameService.getInstance().getNextPlayerId(), name);
			players.add(player);
		}

		return player;
	}

	@Override
	public String toString() {
		return "Team [id=" + getId() + ", name=" + getName() + "]";
	}
}