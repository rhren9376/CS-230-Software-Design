package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author Richard Hren
 * richard.hren@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	/*
	 * Holds the next team identifier
	 */
	private static long nextTeamId = 1;

	/*
	 * Holds the next player identifier
	 */
	private static long nextPlayerId = 1;

	/*
	 * Singleton Pattern:
	 * Ensures only one instance of GameService exists.
	 */
	private static GameService instance = new GameService();

	/*
	 * Private constructor prevents external instantiation.
	 */
	private GameService() {

	}

	/*
	 * Public accessor method for singleton instance.
	 */
	public static GameService getInstance() {
		return instance;
	}

	/**
	 * Construct a new game instance
	 * 
	 * @param name unique game name
	 * @return new or existing game instance
	 */
	public Game addGame(String name) {

		Game game = null;

		/*
		 * Iterator Pattern:
		 * Loop through games to ensure uniqueness.
		 */
		Iterator<Game> gameIterator = games.iterator();

		while (gameIterator.hasNext()) {

			Game existingGame = gameIterator.next();

			if (existingGame.getName().equalsIgnoreCase(name)) {
				game = existingGame;
				break;
			}
		}

		// Create game if not found
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		return game;
	}

	/**
	 * Returns game by index
	 * 
	 * @param index game index
	 * @return requested game
	 */
	Game getGame(int index) {
		return games.get(index);
	}

	/**
	 * Returns game by id
	 * 
	 * @param id unique game id
	 * @return requested game
	 */
	public Game getGame(long id) {

		Game game = null;

		Iterator<Game> gameIterator = games.iterator();

		while (gameIterator.hasNext()) {

			Game existingGame = gameIterator.next();

			if (existingGame.getId() == id) {
				game = existingGame;
				break;
			}
		}

		return game;
	}

	/**
	 * Returns game by name
	 * 
	 * @param name unique game name
	 * @return requested game
	 */
	public Game getGame(String name) {

		Game game = null;

		Iterator<Game> gameIterator = games.iterator();

		while (gameIterator.hasNext()) {

			Game existingGame = gameIterator.next();

			if (existingGame.getName().equalsIgnoreCase(name)) {
				game = existingGame;
				break;
			}
		}

		return game;
	}

	/**
	 * Returns number of active games
	 * 
	 * @return game count
	 */
	public int getGameCount() {
		return games.size();
	}

	/**
	 * Returns next team id
	 * 
	 * @return next team id
	 */
	public long getNextTeamId() {
		return nextTeamId++;
	}

	/**
	 * Returns next player id
	 * 
	 * @return next player id
	 */
	public long getNextPlayerId() {
		return nextPlayerId++;
	}
}
