package com.gamingroom;

/*
 * A simple base class to define shared
 * characteristics for Game, Team, and Player.
 */
public class Entity {

    // Unique identifier for the entity
    private long id;

    // Name of the entity
    private String name;

    /*
     * Constructor
     */
    public Entity(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /*
     * Returns the unique identifier
     */
    public long getId() {
        return id;
    }

    /*
     * Returns the entity name
     */
    public String getName() {
        return name;
    }

    /*
     * Returns formatted entity information
     */
    @Override
    public String toString() {
        return String.format("Entity [id=%d, name=%s]", id, name);
    }
}