package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a game.
 * 
 * @author Richard Hren
 * richard.hren@snhu.edu
 */
public class Game extends Entity {

	/*
	 * List of teams associated with the game
	 */
	private List<Team> teams = new ArrayList<Team>();

	/**
	 * Hide the default constructor.
	 */
	private Game() {
		super(0, "");
	}

	/**
	 * Constructor with an identifier and name.
	 */
	public Game(long id, String name) {
		super(id, name);
	}

	/**
	 * Adds a team if the name does not already exist.
	 * 
	 * @param name unique team name
	 * @return new or existing team
	 */
	public Team addTeam(String name) {

		Team team = null;

		Iterator<Team> teamIterator = teams.iterator();

		while (teamIterator.hasNext()) {

			Team existingTeam = teamIterator.next();

			if (existingTeam.getName().equalsIgnoreCase(name)) {
				team = existingTeam;
				break;
			}
		}

		if (team == null) {
			team = new Team(GameService.getInstance().getNextTeamId(), name);
			teams.add(team);
		}

		return team;
	}

	@Override
	public String toString() {
		return "Game [id=" + getId() + ", name=" + getName() + "]";
	}
}
