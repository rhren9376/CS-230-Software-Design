package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author Richard Hren
 * richard.hren@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	/*
	 * Singleton Pattern:
	 * The singleton pattern ensures that only one instance
	 * of the GameService class exists in memory at any time.
	 * This provides centralized management of all active games
	 * and prevents duplicate service objects from being created.
	 * This is similar to centralized control systems used in
	 * automation environments where a single controller manages
	 * shared resources and system state.
	 */
	private static GameService instance = new GameService();

	/*
	 * Private constructor prevents external instantiation.
	 */
	private GameService() {

	}

	/*
	 * Public accessor method to obtain the singleton instance.
	 */
	public static GameService getInstance() {
		return instance;
	} 


	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		/*
		 * Iterator Pattern:
		 * The iterator pattern is used to loop through the
		 * collection of active games stored in memory.
		 * This allows the application to verify that duplicate
		 * game names are not created by users.
		 */
		for (Game existingGame : games) {
			if (existingGame.getName().equalsIgnoreCase(name)) {
				game = existingGame;
				break;
			}
		}

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		for (Game existingGame : games) {
			if (existingGame.getId() == id) {
				game = existingGame;
				break;
			}
		}

		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		for (Game existingGame : games) {
			if (existingGame.getName().equalsIgnoreCase(name)) {
				game = existingGame;
				break;
			}
		}

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
